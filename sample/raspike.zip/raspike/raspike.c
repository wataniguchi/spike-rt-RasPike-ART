/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2022-2023 Embedded and Real-Time Systems Laboratory,
 *            Graduate School of Information Science, Nagoya Univ., JAPAN
 */

#include <kernel.h>
#include <kernel_cfg.h>
#include <t_syslog.h>
#include <stdio.h>
#include <string.h>
#include <serial/serial.h>
#include <spike/hub/system.h>
#include <spike/pup/motor.h>
//#include "app_config.h"
#include "spike/hub/button.h"

#include "raspike.h"


static int send_data(const char* buf, size_t size)
{
  ER ercd;
  ercd = serial_wri_dat(SIO_USB_PORTID,buf,size);

  if ( ercd == E_OK ) return ercd;
  dly_tsk(10*1000);
  return 0;

}

static int wait_read(const char* buf, size_t size)
{
   return serial_rea_dat(SIO_USB_PORTID, buf, size);
}


/*
 * Application Main Task
 */
void
main_task(intptr_t exinf)
{
  pbio_error_t err;
  pup_motor_t *motor;
  serial_opn_por(SIO_USB_PORTID);
  serial_ctl_por(SIO_USB_PORTID,0);

  unsigned char start_code[] = {0x1};  

  unsigned char buf[255];
#if 0
  motor = pup_motor_get_device(PBIO_PORT_ID_D);

  if(motor == NULL) {
    hub_system_shutdown();
  }
  
  bool reset_count = true;
  err = pup_motor_setup(motor, PUP_DIRECTION_CLOCKWISE, reset_count);
  if(motor == NULL) {
    hub_system_shutdown();
  }
#endif

// ボタンを押して1秒後に開始
hub_display_char('S');
while(1) {
  hub_button_t pressed;
  hub_button_is_pressed(&pressed);
  if ( pressed & HUB_BUTTON_CENTER ) break;
}
dly_tsk(1000*1000);



  char c=0;
 while (1) {
    int len=1;
//    len = wait_read(&c,1);
    if ( len > 0 ) {
      c++;
      c%=100;
      send_data(&c,1);
      dly_tsk(100*1000);
      hub_display_number(c);
    } else {
      hub_display_number(len);
    }
  hub_button_t pressed;
  hub_button_is_pressed(&pressed);
  if ( pressed & HUB_BUTTON_CENTER ) break;
 }

  hub_system_shutdown();
}
